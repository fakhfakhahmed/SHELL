
recherche()
{
recherche=$(yad --entry --title='Recherche web' --text='Tapez votre recherche' --text-align="center" --no-escape --mouse --undecorated --skip-taskbar --on-top)
recherche=$(echo "$recherche" | sed 's/ /+/g')
xdg-open https://www.google.fr/search?q="$recherche"\&site=webhp\&source=lnt\&tbs=lr:lang_1fr\&lr=lang_fr
}
afficher_pydf()
{
pydf
}
afficherfdik()
{
sudo fdisk -l
}
Mhelp()
{
yad  --title="help"  --image="$backg"   --text="L'option -lpy: report colourised filesystem disk space usage \n L'option -ldk: manipulate disk partition table \n
 L'option -sauvgardepydf: save les données de -lpy \n
-sauvgardefdisk: save les données de -ldk \n
-plot: translate GNU metafiles to other graphics formats \n
-find: chercher les fichier et les dossier avec date \n"

	
}
Mfind()
{
var=`find ~ -name "*$datee*"`                #avec la commande find chercher les fichier qui contienne une date donner 
cat $var                                    #afficher le contenue de ce fichier
}
savepydf()
{
now=$(date +'-%m-%d-%Y')       #recupere la date actuelle
var=$fichier$now.txt           #concatenation du nom du fichier avec la date
pydf > $var                    # affecter la contenue de pydf dans une variable
}
savefdisk()
{
now=$(date +'-%m-%d-%Y')      #recupere la date actuelle
var=$fichier$now.txt          #concatenation du nom du fichier avec la date
sudo fdisk -l > $var         # affecter la contenue de fdisk dans une variable
}
gnuplot_fonction()
{
df | awk '{printf ("%s %s %s \n", $3, $4, $5); }' | head -n 10 > test.dat
sort -h test.dat >tes.dat
./plot.sh
}

db_accueil()
{
yad --title="Menu" --mouse  --text=" Choisissez l'instruction que vous desirez." \
	 --image="$backg"  \
	--height=250 --list --radiolist --no-headers \
	--column 1 --column 2  --print-column=2 \
		 false "lpy" false  "ldk" \
		 true "help" false "sauvgarde pydf" \
		 false "sauvgarde fdisk" false "plot" \
		 false "recherche"  false "find"\
		
}





# Boite de notification #

db_notification()
{

yad  --title="Notification" --mouse --timeout=1 --info --text="succes \!" \
	   --image="$backg"
}
db_notification2()
{
yad  --title="Notification" --mouse --timeout=1 --info --text="Hope i helped you\!" \
	 --image="$backg" 
}

