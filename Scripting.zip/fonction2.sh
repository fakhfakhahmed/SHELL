afficherpydf()
{
pydf 
}
afficherldk()
{
sudo fdisk -l
}
gnuplot_fonction()
{
df | awk '{printf ("%s %s %s \n", $3, $4, $5); }' | head -n 10 > test.dat
sort -h test.dat >tes.dat
./plot.sh
}
savepydf()
{
now=$(date +'-%m-%d-%Y')       #recupere la date actuelle
var=$fichier$now.txt           #concatenation du nom du fichier avec la date
pydf > $var                    # affecter la contenue de pydf dans une variable
}
savefdisk()
{
now=$(date +'-%m-%d-%Y')      #recupere la date actuelle
var=$fichier$now.txt          #concatenation du nom du fichier avec la date
sudo fdisk -l > $var         # affecter la contenue de fdisk dans une variable
}
afficherhelp()
{
echo "********"
echo "-lpy ou -y  : report colourised filesystem disk space usage"
echo "-ldk ou -d : manipulate disk partition table" 
echo " -plot ou -p : translate GNU metafiles to other graphics formats"           #inforamtion sur les commande
echo " -s save les données de -lpy "
echo " -s2 ou -a save les données de -ldk"
echo " -yad ou -g afficher interface graphique"
echo "-find ou -o chercher les fichier et les dossier avec date"
echo "*********"
}
afficherdate()
{
var=`find ~ -name "*$datee*"`                #avec la commande find chercher les fichier qui contienne une date donner 
cat $var                                    #afficher le contenue de ce fichier
}

menu()
{
while true
do
echo ""
echo "    sujet 5   "
echo ""  
echo " 1) la commande -lpy"
echo " 2) la commande -ldk"
echo " 3) -h ou -help"
echo " 4) la commande plot ou gnuplot"                 #menu
echo " 5) la commande -s"
echo " 6) la commande -s2"
echo " 7) la commande -find"
echo " 8) la commande -yad"
echo " 9) exit"
echo "  "
echo "donner votre choix"
read INPUT_STRING                     #recupere le choix sous forme de chaine de caracter
case $INPUT_STRING in
-lpy)
afficherpydf                          #appele de fonction pydf
;;
-ldk)
afficherldk                           #appele de fonction ldk
;;
-h)
afficherhelp                           #appele de fonction help
;;
-help)
afficherhelp
;;
-s)
echo "donner le nom de fichier"
read fichier                            #recuperer le nom de fichier
savepydf
;;
-s2)
echo "donner le nom de fichier"
read fichier                            #recuperer le nom de fichier
savefdisk
;;
-plot)
gnuplot_fonction                         #appele la fonction plot
;;
-gnuplot)
gnuplot_fonction  			#appele la fonction plot
;;
-yad)
graphique                                #appele la fonction graphique pour ouvrire l'interface graphique
;;
-find)
echo "donner la date "
read datee				#recuperer la date  de fichier
    afficherdate                                #recuperer la fonction find
;;
exit)
echo "GOOD Bay !"
exit
;;
esac
done 
}
