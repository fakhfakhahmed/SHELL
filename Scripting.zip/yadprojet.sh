

graphique()
{
source fonction.sh


# Variables #


backg=/home/patata/ma.png





# Programme #

programme()
{
CHOIX=`db_accueil`
case $? in
252|1) # An error occured or the box was closed | Cancel/No pressed
	exit 0
;;
0) # All OK
	case $CHOIX in
	"lpy|")
		afficher_pydf
		db_notification
	;;
	"ldk|")
		afficherfdik
		db_notification
	;;
	"sauvgarde pydf|")
		echo "donnez le nom de fichier"
		read fichier
		savepydf
		db_notification

	;;
	"sauvgarde fdisk|")
		echo "donnez le nom de fichier"
		read fichier
		savefdisk
		db_notification

	;;
	"recherche|")
		
		recherche
			db_notification
	;;
	"plot|")
		
		gnuplot_fonction
			db_notification
	;;
	"help|")
		Mhelp
			db_notification2
	;;
	"find|")
			echo "donnez la date"
				read datee
		Mfind
			db_notification
	;;
	"Autre|")
		CHOIX=`db_autre`
		case $? in
		252) # An error occured or the box was closed
			exit 0
		;;
		1) # Cancel/No pressed
 			programme
		;;
		0) # All OK
			sleep "$CHOIX"s
			db_notification
		;;
		esac
	;;
	esac
;;
esac
}

# Lancement effectif #

programme
}

