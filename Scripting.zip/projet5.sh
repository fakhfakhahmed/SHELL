#!/bin/bash
source yadprojet.sh
source fonction2.sh

while getopts "mydphs:o:a:g" options
do
case $options in
m)
menu
;;
y)
afficherpydf				#appele de fonction pydf
;;
d)
afficherldk			#appele de fonction ldk
;;
p)
gnuplot_fonction		 #recupere la fonction plot
;;
h)
afficherhelp		#appele de fonction help
;;
s)
fichier=$OPTARG				 #recuperer le nom de fichier
savepydf
;;
a)
fichier=$OPTARG				 #recuperer le nom de fichier
savefdisk
;;
g)
graphique			  #recupere la fonction graphique pour ouvrire l'interface
;;
o)
datee=$OPTARG			#recuperer la date de fichier	
afficherdate				#recuperer la foncion find
;;
esac
done


