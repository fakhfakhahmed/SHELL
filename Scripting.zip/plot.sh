#!/bin/bash

gnuplot -p>load 'load.sh'
