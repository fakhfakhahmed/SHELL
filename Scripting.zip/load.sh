set title "Pydf"
set xlabel "Giga"
set ylabel "Mega"
set xrange [10:10000]

plot "tes.dat" using 1:1 w lp t "Size" , "tes.dat" using 1:2 w lp t "used"
